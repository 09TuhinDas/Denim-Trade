from src.utils.notifier import notify

notify("Trading Bot ✅", "2 BUY signals triggered today.")
